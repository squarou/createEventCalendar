<?php
/**
 * Default English Lexicon Entries for CreateEventCalendar
 *
 * @package createeventcalendar
 * @subpackage lexicon
 */

$_lang['createeventcalendar'] = 'CreateEventCalendar';

