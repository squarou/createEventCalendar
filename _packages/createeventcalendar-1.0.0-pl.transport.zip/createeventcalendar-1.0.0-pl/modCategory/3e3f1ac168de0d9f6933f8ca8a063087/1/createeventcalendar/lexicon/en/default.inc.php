<?php
/**
 * Default English Lexicon Entries for CreateEventCalendar
 *
 * @package createeventcalendar
 * @subpackage lexicon
 */

$_lang['createeventcalendar'] = 'CreateEventCalendar';

$_lang['setting_createeventcalendar.user_name'] = 'Your name';
$_lang['setting_createeventcalendar.user_name_desc'] = 'Is used for the Sterc Extra\'s newsletter
subscription. (optional)';
$_lang['setting_createeventcalendar.user_email'] = 'Your emailaddress';
$_lang['setting_createeventcalendar.user_email_desc'] = 'Is used for the Sterc Extra\'s newsletter
subscription. (optional)';
